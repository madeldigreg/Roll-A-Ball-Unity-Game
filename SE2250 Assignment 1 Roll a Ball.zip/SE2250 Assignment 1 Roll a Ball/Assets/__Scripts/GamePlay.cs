﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GamePlay : MonoBehaviour
{
    private Rigidbody rb;
    private float horizontalInput;
    private float verticalInput;
    private float speed = 12.0f;
    private int scoreCount;
    public UnityEngine.UI.Text scoreText;
    public Text winText;
    public GameObject cubePrefab;
    public GameObject coinPrefab;
    public GameObject flowerPrefab;


    void Start()
    {
        rb = GetComponent<Rigidbody>();
        scoreCount = 0;
        setScoreText();
        winText.text = "";

        // Dynamically create 3 cube pickups
        Instantiate(cubePrefab, new Vector3(UnityEngine.Random.Range(-3, 3), 1, UnityEngine.Random.Range(-16, -10)), Quaternion.identity);
        Instantiate(cubePrefab, new Vector3(UnityEngine.Random.Range(-8, -2), 1, UnityEngine.Random.Range(-8, -2)), Quaternion.identity);
        Instantiate(cubePrefab, new Vector3(UnityEngine.Random.Range(2, 8), 1, UnityEngine.Random.Range(2, 8)), Quaternion.identity);

        // Dynamically create 3 coin pickups
        Instantiate(coinPrefab, new Vector3(UnityEngine.Random.Range(2, 8), 1, UnityEngine.Random.Range(-8, -2)), Quaternion.identity);
        Instantiate(coinPrefab, new Vector3(UnityEngine.Random.Range(-8, -2), 1, UnityEngine.Random.Range(2, 8)), Quaternion.identity);
        Instantiate(coinPrefab, new Vector3(UnityEngine.Random.Range(-3, 3), 1, UnityEngine.Random.Range(10, 18)), Quaternion.identity);

        // Dynamically create 2 flower pickups
        Instantiate(flowerPrefab, new Vector3(UnityEngine.Random.Range(10, 18), 1, UnityEngine.Random.Range(-3, 3)), Quaternion.identity);
        Instantiate(flowerPrefab, new Vector3(UnityEngine.Random.Range(-10, -18), 1, UnityEngine.Random.Range(-3, 3)), Quaternion.identity);
    }

    void Update()
    {
        // Player controls movement using arrow keys
        horizontalInput = Input.GetAxis("Horizontal");
        verticalInput = Input.GetAxis("Vertical");

        // When the player has picked up all the pickups, the game resets
        if (scoreCount >= 85)
        {
            StartCoroutine(gameReset());
        }
    }

    private void FixedUpdate()
    {
        // Force to move the ball
        rb.AddForce(new Vector3(horizontalInput, 0.0f, verticalInput)*speed);
    }

    // Handler event for when the player ball touches a pick up item
    private void OnTriggerEnter(Collider other)
    {
        // If the player touches a cube, the cube disappears and the score increases by 5
        if (other.gameObject.CompareTag("Cube Pick Up"))
        {
            other.gameObject.SetActive(false);
            scoreCount += 5;
            setScoreText();
        }

        // If the player touches a coin, the coin disappears and the score increases by 10
        if (other.gameObject.CompareTag("Coin Pick Up"))
        {
            other.gameObject.SetActive(false);
            scoreCount += 10;
            setScoreText();
        }

        // If the player touches a flower, the flower disappears and the score increases by 20
        if (other.gameObject.CompareTag("Flower Pick Up"))
        {
            other.gameObject.SetActive(false);
            scoreCount += 20;
            setScoreText();
        }
    }

    // Text displayed in the top right corner of the game to keep track of current score
    void setScoreText()
    {
        scoreText.text = "Score: " + scoreCount.ToString();
    }

    // After all pickups are gone, the game pauses for 2 seconds then resets
    IEnumerator gameReset()
    {
        winText.text = "You Win!";
        Time.timeScale = 0;
        yield return new WaitForSecondsRealtime(2);
        Time.timeScale = 1;
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
