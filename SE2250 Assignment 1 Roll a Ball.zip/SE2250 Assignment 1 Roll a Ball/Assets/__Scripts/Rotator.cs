﻿using UnityEngine;

// This script creates rotation of the pickup objects, making them appear more interesting/attractive to pick up for the player

public class Rotator : MonoBehaviour
{
    void Update()
    {
        transform.Rotate(new Vector3(15, 30, 45) * Time.deltaTime);
    }
}
