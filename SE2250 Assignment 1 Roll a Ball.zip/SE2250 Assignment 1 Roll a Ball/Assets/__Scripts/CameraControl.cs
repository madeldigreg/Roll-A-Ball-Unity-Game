﻿using UnityEngine;

// This script controls the camera such that the camera follows the player around

public class CameraControl : MonoBehaviour
{
    public GameObject player;
    private Vector3 cameraOffset;

    void Start()
    {
        cameraOffset = transform.position - player.transform.position;
    }

    private void LateUpdate()
    {
        transform.position = player.transform.position + cameraOffset;
    }
}
